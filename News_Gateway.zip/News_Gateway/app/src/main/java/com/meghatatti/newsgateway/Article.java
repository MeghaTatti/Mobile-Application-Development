package com.meghatatti.newsgateway;

import java.io.Serializable;



public class Article implements Serializable {
String artAuthor;
String artTitle;
String artDescription;
String artUrlToImage;
String artPublished;
String artUrl;

    public String getArtUrl() {
        return artUrl;
    }

    public void setArtUrl(String artUrl) {
        this.artUrl = artUrl;
    }

    public String getArtAuthor() {
        return artAuthor;
    }

    public void setArtAuthor(String artAuthor) {
        this.artAuthor = artAuthor;
    }

    public String getArtTitle() {
        return artTitle;
    }

    public void setArtTitle(String artTitle) {
        this.artTitle = artTitle;
    }

    public String getArtDescription() {
        return artDescription;
    }

    public void setArtDescription(String artDescription) {
        this.artDescription = artDescription;
    }

    public String getArtUrlToImage() {
        return artUrlToImage;
    }

    public void setArtUrlToImage(String artUrlToImage) {
        this.artUrlToImage = artUrlToImage;
    }

    public String getArtPublished() {
        return artPublished;
    }

    public void setArtPublished(String artPublished) {
        this.artPublished = artPublished;
    }
}
