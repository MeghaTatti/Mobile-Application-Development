package com.example.megha.multinotes_assignment2;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.util.JsonReader;
import android.util.JsonWriter;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.OutputStreamWriter;
import java.io.StringWriter;
import java.util.ArrayList;


public class Util extends AppCompatActivity{
    public static boolean saveNote(Context context, Notes content){
        try{
            FileOutputStream fos = context.openFileOutput( content.getTitle() +".json", Context.MODE_PRIVATE);
            JsonWriter jsonWriter = new JsonWriter(new OutputStreamWriter(fos, context.getString(R.string.encoding)));
            jsonWriter.beginObject();
            jsonWriter.name("Content").value(content.getContent());
            jsonWriter.name("DateTime").value(content.getDateTime());
            jsonWriter.name("Title").value(content.getTitle());
            jsonWriter.endObject();
            jsonWriter.close();
        }
        catch(Exception e){
            e.getStackTrace();
            return false;
        }
        return true;
    }

    public static ArrayList<Notes> getAllSavedNotes(Context context){
        ArrayList<Notes> notesList = new ArrayList<>();
        File filesDir = context.getFilesDir();
        ArrayList<String> arrayList = new ArrayList<>();
        for(String file : filesDir.list()){
            if(file.endsWith(".json")){
                arrayList.add(file);
            }
        }
        for(int i=0; i<arrayList.size();i++) {
            try {
                InputStream is = context.openFileInput(arrayList.get(i));
                JsonReader reader = new JsonReader(new InputStreamReader(is, "UTF-8"));
                Notes ncontent = new Notes();
                reader.beginObject();
                while (reader.hasNext()) {
                    String title = reader.nextName();
                    Log.e("LoadFiles", "loadFile: " + title);
                    if (title.equals("Content")) {
                        ncontent.setContent(reader.nextString());
                    } else if (title.equals("DateTime")) {
                        ncontent.setDateTime(reader.nextLong());
                    } else if (title.equals("Title")) {
                        ncontent.setTitle(reader.nextString());
                    } else reader.skipValue();
                }
                reader.endObject();
                notesList.add(ncontent);
            } catch (FileNotFoundException e) {
                Toast.makeText(context, "File Not Found", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return notesList;
    }

    public static boolean deleteNote(Context context, String filename) {
        File file = new File(context.getFilesDir(), filename);
        return file.delete();
    }

}
