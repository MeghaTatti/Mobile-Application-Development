package com.example.megha.multinotes_assignment2;

import android.app.Activity;
import android.os.Bundle;

public class AppInfoActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.info);
    }
}
