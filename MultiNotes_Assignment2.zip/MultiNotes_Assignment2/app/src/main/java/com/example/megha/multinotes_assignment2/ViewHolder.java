package com.example.megha.multinotes_assignment2;

import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class ViewHolder extends RecyclerView.Adapter<ViewHolder.Holder> {

    ArrayList<Notes> notes;
    private int itemLayout;
    private static ClickListener clickListener;
    private static LongClickListner longClickListner;

    public ViewHolder(ArrayList<Notes> notes, int itemLayout) {
        this.notes = notes;
        this.itemLayout = itemLayout;
    }

    @Override
    public Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.noteslist, parent, false);
        return new Holder(view);
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    @Override
    public void onBindViewHolder(Holder holder, int position) {
        Notes item = notes.get(position);
        holder.title.setText(item.getTitle());

        SimpleDateFormat sdf = new SimpleDateFormat();
        sdf.applyPattern("MM-dd-yyyy hh:mm:ss");
        holder.dateTime.setText(sdf.format(item.getDateTime()));

        if ((item.getContent().length()) < 80) {
            holder.content.setText(item.getContent());
        } else {
            holder.content.setText(item.getContent().substring(0, 79) + "..");
        }

        holder.itemView.setTag(item);
    }

    public void setOnItemClickListener(ClickListener clickListener) {
        this.clickListener = clickListener;
    }

    public void setOnItemLongClickListener(LongClickListner longClickListner) {
        this.longClickListner = longClickListner;
    }


    public class Holder extends RecyclerView.ViewHolder implements View.OnClickListener, View.OnLongClickListener {
        public TextView title;
        public TextView dateTime;
        public TextView content;
        Notes ncontent = new Notes();

        public Holder(View itemView) {

            super(itemView);

            title = (TextView) itemView.findViewById(R.id.title);
            dateTime = (TextView) itemView.findViewById(R.id.dateTime);
            content = (TextView) itemView.findViewById(R.id.content);
            itemView.setOnClickListener(this);
            itemView.setOnLongClickListener(this);
        }

        @Override
        public void onClick(View v) {
            clickListener.onItemClick(getPosition(), v);
        }

        @Override
        public boolean onLongClick(View v) {
            longClickListner.onItemLongClick(getPosition(), v);
            return false;
        }
    }


    public interface ClickListener {
        public void onItemClick(int position, View v);
    }

    public interface LongClickListner {
        public void onItemLongClick(int position, View v);

    }
}

