package com.example.megha.multinotes_assignment2;

public class Notes {

    private String title;
    private long dateTime;
    private String content;

    public Notes(String title,long dateTime,String content){
        this.title=title;
        this.dateTime=dateTime;
        this.content=content;
    }

    public Notes() {
    }

    public String getTitle() {

        return title;
    }

    public void setTitle(String title) {

        this.title = title;
    }

    public long getDateTime()
    {
        return dateTime;
    }

    public void setDateTime(long dateTime) {

        this.dateTime = dateTime;
    }

    public String getContent()
    {
        return content;
    }

    public void setContent(String content) {

        this.content = content;
    }

        }


