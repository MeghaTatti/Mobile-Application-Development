package com.example.megha.multinotes_assignment2;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;


public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private Context context;
    ViewHolder viewHolder;
    ArrayList<Notes> notes;
    NotesActivity notesActivity;
    private static final String TAG = "MainActivity";
    LinearLayoutManager linearLayoutManager;
    static int pos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView = (RecyclerView)findViewById(R.id.contentView);
        context=this;
        linearLayoutManager =new LinearLayoutManager(context);
        recyclerView.setLayoutManager(linearLayoutManager);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.mainmenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.info:
                startActivity(new Intent(getApplicationContext(),AppInfoActivity.class));
                return true;
            case R.id.create:
                startActivity(new Intent(getApplicationContext(),NotesActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        notes=new ArrayList<>();
        viewHolder = new ViewHolder(notes, R.layout.noteslist);
        /*notesActivity= new NotesActivity(notes);*/
        viewHolder.setOnItemClickListener(new ViewHolder.ClickListener() {
            @Override
            public void onItemClick(int position, View v) {
                Intent viewNoteIntent = new Intent(getApplicationContext(), NotesActivity.class);
                viewNoteIntent.putExtra("content",(notes.get(position).getContent()));
                viewNoteIntent.putExtra("dateTime",(notes.get(position).getDateTime()));
                viewNoteIntent.putExtra("title",(notes.get(position).getTitle()));
                startActivity(viewNoteIntent);
               /* View parent1 = (View) v.getParent();
                ListView view1= (ListView) parent1.getParent();
                pos = view1.getPositionForView(parent1);
                Log.d(TAG, "Train: "+pos);*/
            }
        });
        viewHolder.setOnItemLongClickListener(new ViewHolder.LongClickListner() {
            @Override
            public void onItemLongClick(int position, View v) {
                deleteNote(notes.get(position).getTitle(),position);
            }
        });

        new AsyncTask<Void, Void, ArrayList<Notes>>() {
            @Override
            protected ArrayList<Notes> doInBackground(Void... params) {
                notes= Util.getAllSavedNotes(context);
                return notes;
            }
            @Override
            protected void onPostExecute(ArrayList<Notes> aVoid) {
                super.onPostExecute(aVoid);
                if((notes==null)||(notes.size()==0)){
                    Toast.makeText(context, "You have no saved notes", Toast.LENGTH_SHORT).show();

                }
                viewHolder =new ViewHolder(notes, R.layout.noteslist);
                Collections.reverse(notes);
                recyclerView.setAdapter(viewHolder);
                viewHolder.notifyDataSetChanged();
            }
        }.execute();
    }

    private void deleteNote(final String title, final int position){
        AlertDialog.Builder dialog = new AlertDialog.Builder(this)
                .setTitle(" Delete")
                .setMessage("Are you sure you want to delete '"+title +"' ??")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        if(Util.deleteNote(getApplicationContext(), title+  ".json"))
                        {
                            Toast.makeText(getApplicationContext(),title+ " is deleted", Toast.LENGTH_SHORT).show();
                            notes.remove(position);
                            viewHolder.notifyDataSetChanged();
                        }
                    }

                })
                .setNegativeButton("no",null)
                .setCancelable(false);
        dialog.show();
    }
    @Override
    public void onBackPressed(){
        android.os.Process.killProcess(android.os.Process.myPid());
    }
}
