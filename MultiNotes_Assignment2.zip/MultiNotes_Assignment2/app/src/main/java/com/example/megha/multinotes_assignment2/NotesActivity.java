package com.example.megha.multinotes_assignment2;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class NotesActivity extends AppCompatActivity {

    private static final String TAG = "NotesActivity";
    EditText title,ncontent;
    Notes notes;
    static String oldTitle, oldContent;
    ArrayList<Notes> noteslist;

   /* public NotesActivity(ArrayList<Notes> noteslist)
    {
        this.noteslist=noteslist;
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notes);
        title=findViewById(R.id.title_view);
        ncontent=findViewById(R.id.content_view);
        notes = new Notes();
        oldTitle = getIntent().getStringExtra("title");
        oldContent = getIntent().getStringExtra("content");
        title.setText(oldTitle);
        ncontent.setText(oldContent);
        notes.setTitle(oldTitle);
        notes.setContent(oldContent);
        notes.setDateTime(getIntent().getLongExtra("dateTime",0));
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.savemenu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.save)
            saveContent();
        return true;
    }

    @Override
    public void onBackPressed(){
        if (title.getText().toString().isEmpty()){
            Toast.makeText(getApplicationContext(), "Activity not saved", Toast.LENGTH_SHORT).show();
            finish();
            startActivity(new Intent(getApplicationContext(),MainActivity.class));
        } else if (title.getText().toString().equals(oldTitle) && ncontent.getText().toString().equals(oldContent)) {
            finish();
            startActivity(new Intent(getApplicationContext(), MainActivity.class));
        }
        else if (!title.getText().toString().equals(oldTitle) || !ncontent.getText().toString().equals(oldContent)){

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Save Note")
                    .setMessage("Do you want to save this note???")
                    .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            saveContent();
                        }
                    })
                    .setNegativeButton("No", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which) {
                            startActivity(new Intent(getApplicationContext(), MainActivity.class));
                            finish();
                        }
                    })
                    .show();
        }
    }

    private void saveContent(){
        Log.d(TAG, "saveNotes: SaveNotes");
        if (title.getText().toString().isEmpty()){
            Toast.makeText(getApplicationContext(), "Activity not saved", Toast.LENGTH_SHORT).show();
            startActivity(new Intent(getApplicationContext(),MainActivity.class));
        }
        else {
            if (notes == null) {
                notes = new Notes(title.getText().
                        toString(),System.currentTimeMillis(),ncontent.getText().toString());
            } else {
                notes.setTitle(title.getText().toString());
                notes.setContent(ncontent.getText().toString());
                notes.setDateTime(System.currentTimeMillis());
            }
            if (Util.saveNote(this, notes)) {
                Toast.makeText(this, "Note is saved", Toast.LENGTH_SHORT).show();
            }
        }
        finish();
    }
}
