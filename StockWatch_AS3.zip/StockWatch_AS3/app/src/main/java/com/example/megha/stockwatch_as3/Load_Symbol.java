package com.example.megha.stockwatch_as3;

import android.content.DialogInterface;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;


public class Load_Symbol extends AsyncTask<String, Void, String> {
    private MainActivity mainActivity;
    private final String prefix = "http://d.yimg.com/aq/autoc?region=US&lang=en-US&query=";

    public Load_Symbol(MainActivity mainActivity) {

        this.mainActivity = mainActivity;
    }

    @Override
    protected String doInBackground(String... params) {

        StringBuilder sb = new StringBuilder();
        try {
            URL url = new URL(prefix + params[0]);


            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            InputStream is = conn.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

            String l;
            while ((l = reader.readLine()) != null) sb.append(l).append("\n");

        } catch (java.io.IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

    @Override
    protected void onPostExecute(String s) {
        final List<Stock> cList = parseJson(s);
        AlertDialog.Builder builder = new AlertDialog.Builder(mainActivity);
        final Stock[] stock = new Stock[1];

        if (cList.size()==0) {
            builder.setTitle("Stock Not Found").setIcon(android.R.drawable.ic_dialog_alert);
            builder.setMessage("Incorrect Stock Name");
            builder.setPositiveButton("OK", null);
            AlertDialog alert = builder.create();
            alert.show();
            return;
        } else if (cList.size() == 1) {
            stock[0] = cList.get(0);
            StockInfoLoad ob = new StockInfoLoad(mainActivity);
            ob.execute(stock[0]);
        } else {
            CharSequence[] stocks = new CharSequence[cList.size()];
            int i = 0;
            for (Stock each : cList) {
                CharSequence temp = each.getSymbol() + " - " + each.getName();
                stocks[i] = temp;
                i++;
            }

            builder.setTitle("Make a selection");
            builder.setItems(stocks, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    stock[0] = cList.get(which);
                    StockInfoLoad ob = new StockInfoLoad(mainActivity);
                    ob.execute(stock[0]);

                }
            });
            builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            });

            AlertDialog alert = builder.create();
            alert.show();
        }
    }

    private List<Stock> parseJson(String res) {
        List<Stock> candidateList = new ArrayList<>();

        try {
            JSONObject jsonOb = new JSONObject(res);
            JSONObject object = jsonOb.getJSONObject("ResultSet");
            JSONArray jObjMain = object.getJSONArray("Result");

            for (int i = 0; i < jObjMain.length(); i++) {
                JSONObject jStock = (JSONObject) jObjMain.get(i);
                Stock stock = new Stock(jStock.getString("symbol"), jStock.getString("name"));
                candidateList.add(stock);
            }
            return candidateList;
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return null;
    }
}
