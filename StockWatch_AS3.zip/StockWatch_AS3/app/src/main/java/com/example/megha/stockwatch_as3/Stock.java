package com.example.megha.stockwatch_as3;

public class Stock {

    private String symbol;
    private String name;
    private double price;
    private double priceChange;
    private double percentChange;

    public Stock(String sym, String info) {
        this.symbol = sym;
        this.name = info;
    }

    public String getSymbol() {
        return symbol;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public double getPriceChange() {
        return priceChange;
    }

    public double getPercentChange() {
        return percentChange;
    }

    public void setSymbol(String sym) {
        this.symbol = sym;
    }

    public void setName(String info) {
        this.name = info;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setPriceChange(double priceChange) {
        this.priceChange = priceChange;
    }

    public void setPercentChange(double percentChange) {
        this.percentChange = percentChange;
    }
}
