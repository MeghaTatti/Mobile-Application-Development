package com.example.megha.stockwatch_as3;

import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

public class Stock_Adapter extends RecyclerView.Adapter<Stock_Holder> {

    private List<Stock> stocks;
    private MainActivity mainActivity;

    @Override
    public Stock_Holder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.stocklist, parent, false);
        view.setOnLongClickListener(mainActivity);
        view.setOnClickListener(mainActivity);
        return new Stock_Holder(view);
    }

    public Stock_Adapter(MainActivity mainActivity, List<Stock> stocks) {
        this.mainActivity = mainActivity;
        this.stocks = stocks;
    }

    @Override
    public void onBindViewHolder(Stock_Holder stockHolder, int position) {
        Stock stock = stocks.get(position);
        stockHolder.stockName.setText(stock.getName());
        stockHolder.stockPrice.setText(String.valueOf(stock.getPrice()));
        stockHolder.stockSymbol.setText(stock.getSymbol());
        if (stock.getPriceChange() > 0)
        {
            stockHolder.change.setText("▲ "+String.valueOf(stock.getPriceChange())+"("+String.valueOf(stock.getPercentChange()).substring(0,5)+"%)");
            stockHolder.stockName.setTextColor(Color.GREEN);
            stockHolder.stockPrice.setTextColor(Color.GREEN);
            stockHolder.stockSymbol.setTextColor(Color.GREEN);
            stockHolder.change.setTextColor(Color.GREEN);
        }else{
            stockHolder.change.setText("▼ "+String.valueOf(stock.getPriceChange())+"("+String.valueOf(stock.getPercentChange()).substring(0,5)+"%)");
            stockHolder.stockName.setTextColor(Color.RED);
            stockHolder.stockPrice.setTextColor(Color.RED);
            stockHolder.stockSymbol.setTextColor(Color.RED);
            stockHolder.change.setTextColor(Color.RED);
        }
    }

    @Override
    public int getItemCount() {
        return stocks.size();
    }
}
