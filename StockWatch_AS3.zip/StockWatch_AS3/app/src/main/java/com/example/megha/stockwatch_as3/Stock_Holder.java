package com.example.megha.stockwatch_as3;


import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.TextView;

public class Stock_Holder extends RecyclerView.ViewHolder {
    public TextView stockName;
    public TextView stockSymbol;
    public TextView stockPrice;
    public TextView change;

    public Stock_Holder(View itemView) {
        super(itemView);
        stockName = (TextView) itemView.findViewById(R.id.name);
        stockSymbol = (TextView) itemView.findViewById(R.id.symbol);
        change = (TextView) itemView.findViewById(R.id.change);
        stockPrice = (TextView) itemView.findViewById(R.id.price);
    }
}
