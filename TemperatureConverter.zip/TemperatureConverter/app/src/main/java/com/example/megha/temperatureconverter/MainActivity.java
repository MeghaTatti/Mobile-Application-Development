package com.example.megha.temperatureconverter;

import android.content.res.Configuration;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity {

    EditText In;
    EditText Out;
    RadioButton toCelsius;
    RadioButton toFarenheit;
    TextView display;
    String dst;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        In=(EditText)findViewById(R.id.InputValue);
        Out=(EditText)findViewById(R.id.OutputValue);
        toCelsius=(RadioButton)findViewById(R.id.ToCelsiusRadioButton);
        toFarenheit=(RadioButton)findViewById(R.id.ToFarenheitRadioButton);
        display = (TextView)findViewById(R.id.textView);

    }


@Override
public void onSaveInstanceState(Bundle s)
{
    super.onSaveInstanceState(s);
    dst=display.getText().toString();
    s.putString("edittext",dst);
}

    @Override
    public void onRestoreInstanceState(Bundle r )
    {
        super.onRestoreInstanceState(r);
        display.setText(r.getString("edittext"));
    }

       public void convert(View v) {
        double value = Double.valueOf(In.getText().toString());
        double input=value;
        if (toCelsius.isChecked()){
            value = TempConverter.farenheit2celsius(value);
            Out.setText(""+String.format("%.1f",value));
            display.append("F to C :"+input+"->" +String.format("%.1f",value)+"\n");}

        else{
            value = TempConverter.celsius2farenheit(value);
            Out.setText(""+String.format("%.1f",value));
                display.append("C to F:"+input+"->"+String.format("%.1f",value)+"\n");

                        }
                        display.setMovementMethod(new ScrollingMovementMethod());

    }

}
