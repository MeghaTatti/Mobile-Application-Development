package com.example.megha.temperatureconverter;

public class TempConverter {

    public static double celsius2farenheit(double c)
    {
        return (c*1.8)+32;
    }
    public static double farenheit2celsius(double f)
    {
        return (f-32.0)/1.8;
    }
}
